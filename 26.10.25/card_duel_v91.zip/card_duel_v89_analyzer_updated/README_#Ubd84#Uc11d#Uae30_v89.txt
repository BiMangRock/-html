카드 대전 v89 분석기 업데이트
=============================

포함 파일
- v89.html: 기존 게임 파일 (원본 유지)
- engine_v89.js: v89.html 안에 포함된 엔진 코드의 Node.js 모듈 버전
- analyze_v89.js: v89 엔진 호환 심층 분석기
- 기존 이미지 및 프로젝트 파일: 원본 ZIP 그대로 유지

실행 방법
1. Node.js 18 이상 권장
2. 압축을 푼 폴더에서 터미널/명령 프롬프트 열기
3. 기본 1000판 분석:
   node analyze_v89.js
4. 500판 분석:
   node analyze_v89.js 500
5. 다른 봇으로 분석:
   node analyze_v89.js 500 rule2
   node analyze_v89.js 500 random
6. 파일 저장 없이 실행:
   node analyze_v89.js 100 rule --no-save

봇 이름: rule, rule2, random
출력: 분석결과_v89.json, 경기기록_v89.jsonl (기본 저장 활성화)

변경 사항 및 주의
- 기존 v72 분석기는 playRecordedGame / game.actions / game.cardDraws 같은 v72 기록 API를 사용했지만 v89 엔진에는 해당 API가 없어 그대로는 실행되지 않습니다.
- 분석기는 v89의 newGame / apply / viewFor API로 실행하도록 바꿨습니다.
- 무작위 덱은 v89의 buildRandomDeck를 사용합니다.
- 카드별 승률 차이와 시너지 값은 덱 구성 및 같은 봇 미러전의 교란을 포함하는 탐색용 연관성이지, 카드의 인과적 기여를 증명하지 않습니다.
- v89 엔진이 v72와 동일한 상세 기록을 노출하지 않으므로 기존 버전의 턴별 전황 및 일부 세부 통계는 동일하게 복원되지 않습니다.
- 원본 v89.html 및 이미지 파일은 변경하지 않았습니다.


[v90] 새 이펙트 연결
- v90.html: 새 이펙트가 연결된 게임 파일 (v89.html 은 그대로 보존)
- images/fx_a_*.png : 애니메이션 프레임 스트립 9종 (slash, goldburst, shield, poison, lightning, ice, heal, fireboom, burn)
- images/fx_fireball / fx_bolt_big / fx_ice_burst / fx_heal_pillar .png : 정지 이미지 4종
- 같은 속성에 이미지가 여럿이면 fxV() 가 매번 무작위로 골라 섞어 쓴다 (FX_SCH 의 배열)
