카드 듀얼 튜토리얼
- index.html 을 브라우저로 열면 바로 실행됩니다 (서버 불필요). images 폴더와 같은 위치에 두세요.
- 게임 규칙 엔진은 card_duel_v113 의 v114_adventure6.html 안 <script id="engine"> 을 그대로 가져온 것이라 실제 게임과 규칙이 같습니다.
- 시나리오(고정 손패, 상대 대본, 안내 문구)는 index.html 의 <script id="tutorial"> 안 STEPS / ENEMY_TURNS / buildState 에 있습니다.
- build/ : 템플릿과 빌드 스크립트 (엔진을 다시 끼워 넣을 때 사용)
